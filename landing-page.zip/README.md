# Landing Page Project:

       The main idea of the project is to convert the website from static to dynamic one 
       
#languages used :
       html , css , javascript 
       

#getting start :
       
       first, we download stsrt code form udacity 
#codeing : using javascript

     -we build dynamically navbar , when the user click the button "add section ",it add a link to navebar and also add new section to page 
     
     -scrolling the page , when a section is in the viewport its active state is on 
     
     -clicking a link in navbar , it scrolling smoothly to the specific section
#set up and run :
      
      after downloading project , click on index.html

    
